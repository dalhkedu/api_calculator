package com.valuation.services;

import com.valuation.parameter.PricingParameter;
import com.valuation.services.interfaces.IPricingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
public class PricingServiceTest {

    private IPricingService service;

    @BeforeEach
    public void setUp() {
        this.service = new PricingService();
    }

    @Test
    @DisplayName("Deve realizar o calculo da margem de lucro desejada para um produto")
    public void profitMarginCalculatorTest() {
        var parameter =
                PricingParameter.builder()
                        .percent(BigDecimal.valueOf(35))
                        .price(BigDecimal.valueOf(100))
                        .build();

        var markup = service.profitMarginCalculate(
                parameter.getPrice(), parameter.getPercent());

        assertThat(markup).isEqualTo(BigDecimal.valueOf(153.8462));
    }
}
