package com.valuation.services.interfaces;

import java.math.BigDecimal;

public interface IPricingService {

    BigDecimal profitMarginCalculate (BigDecimal price, BigDecimal percent);
}
