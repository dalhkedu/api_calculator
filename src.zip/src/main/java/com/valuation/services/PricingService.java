package com.valuation.services;

import com.valuation.services.interfaces.IPricingService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.MathContext;

@Service
public class PricingService implements IPricingService {
    @Override
    public BigDecimal profitMarginCalculate(BigDecimal price, BigDecimal percent) {
        return price.divide(
                BigDecimal.valueOf(100)
                        .subtract(percent)
                        .divide(BigDecimal.valueOf(100)), MathContext.DECIMAL32);

    }
}
