package com.valuation.presenters;

import java.math.BigDecimal;

public class StatementOfIncomeForTheYearPresenter {

    private BigDecimal result;
}
