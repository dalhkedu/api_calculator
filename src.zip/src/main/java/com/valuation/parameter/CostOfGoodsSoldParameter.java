package com.valuation.parameter;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

@Data
@Builder
public class CostOfGoodsSoldParameter {

}
