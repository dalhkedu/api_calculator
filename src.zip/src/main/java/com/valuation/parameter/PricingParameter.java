package com.valuation.parameter;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;

@Data
@Builder
public class PricingParameter {

    @NotNull
    @Pattern(regexp = "([0-9]+)")
    private BigDecimal price;
    @NotNull
    private  BigDecimal percent;
}
